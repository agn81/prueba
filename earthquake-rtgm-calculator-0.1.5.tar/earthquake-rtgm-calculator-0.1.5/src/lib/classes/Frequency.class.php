<?php

class Frequency {

  const SA_0P20 = 1.1;
  const SA_1P00 = 1.3;

  public $scale;

  public function __construct ($scale) {
    $this->scale = $scale;
  }

}

?>
