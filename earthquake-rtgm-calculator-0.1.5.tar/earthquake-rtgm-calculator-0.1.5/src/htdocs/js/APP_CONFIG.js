'use strict';

// NOTE: This is a placeholder for compilation
// actual APP_CONFIG are provided by PHP.

throw new Error('APP_CONFIG should not be loaded from base');
