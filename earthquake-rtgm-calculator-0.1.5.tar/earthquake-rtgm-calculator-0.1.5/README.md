Risk-Targeted Ground Motion Calculator
======================================

[![Build Status](https://api.travis-ci.org/usgs/earthquake-rtgm-calculator.png?branch=master)](https://travis-ci.org/usgs/earthquake-rtgm-calculator)

Web application for calculating risk targeted ground motions and risk
coefficients from hazard curves.

License
-------
This software is in the public domain because it contains materials that
originally came from the United States Geological Survey, an agency of the
United States Department of Interior. For more information, see the official
USGS copyright policy at:
https://www.usgs.gov/visual-id/credit_usgs.html#copyright
